package bai5;

public class _Char {
	private char c;
	private int count;
	
	public _Char(char c){
		this.c = c;
		this.count = 1;
	}

	public char getC() {
		return c;
	}

	public void setC(char c) {
		this.c = c;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public void addCount(){
		count++;
	}
	
	
	
}
