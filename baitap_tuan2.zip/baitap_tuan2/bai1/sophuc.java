package bai1;

public class sophuc {
   private float soao;
   private float sothuc;
   
   public sophuc(){
	   sothuc = 0;
	   soao = 0;
   }
   
   public sophuc(float sothuc, float soao){
	   this.soao = soao;
	   this.sothuc = sothuc;
   }
   
	public float getSoao() {
		return soao;
	}
	
	public void setSoao(float soao) {
		this.soao = soao;
	}
	
	public float getSothuc() {
		return sothuc;
	}
	
	public void setSothuc(float sothuc) {
		this.sothuc = sothuc;
	}
   
	//cong hai so phuc
   public static sophuc cong(sophuc so1, sophuc so2){
	   sophuc so3 = new sophuc();
	   so3.setSothuc(so2.getSothuc() + so1.getSothuc());
	   so3.setSoao(so1.getSoao() + so2.getSoao());
	   return so3;
   }

   //tru hai so phuc
   public static sophuc tru(sophuc so1, sophuc so2){
	   sophuc so3 = new sophuc();
	   so3.setSothuc(so1.getSothuc() - so2.getSothuc());
	   so3.setSoao(so1.getSoao() - so2.getSoao());
	   return so3;
   }
   
   //nhan hai so phuc
   public static sophuc nhan(sophuc so1, sophuc so2){
	   sophuc so3 = new sophuc();
	   so3.setSothuc(so1.getSothuc()*so2.getSothuc() - so1.getSoao()*so2.getSoao());
	   so3.setSoao(so1.getSothuc()*so2.getSoao() +  so1.getSoao()*so2.getSothuc());
	   return so3;
   }
   
   //chia hai so phuc
   public static sophuc chia(sophuc so1, sophuc so2){
	   if(so2.getSoao() == 0 && so2.getSothuc() == 0){
		   return null;
	   }
	   sophuc so3 = new sophuc();
	   float sothuc = (float) ((so1.getSothuc()*so2.getSothuc()+so1.getSoao()*so2.getSoao())
			   /(Math.pow(so2.getSoao(), 2)+Math.pow(so2.getSothuc(), 2)));
	   float soao = (float) ((so2.getSothuc()*so1.getSoao() - so1.getSothuc()*so2.getSoao())
			   /(Math.pow(so2.getSoao(), 2)+Math.pow(so2.getSothuc(), 2)));
	   so3.setSoao(soao);
	   so3.setSothuc(sothuc);
	   return so3;
   } 
   
   public static void hienthi(sophuc so){
	   System.out.println("so phuc: "+so.getSothuc()+" + ("+so.getSoao()+"i)");
   }
   
   public static void main(String[] args){
	   sophuc so1 = new sophuc(1,2);
	   sophuc so2 = new sophuc(2,2);
	   hienthi(sophuc.cong(so1, so2));
	   hienthi(sophuc.tru(so1, so2));
	   hienthi(sophuc.nhan(so1, so2));
	   hienthi(sophuc.chia(so1, so2));
   }
}
