package bai4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class bai4 {
	ArrayList<Word> dictionary = new ArrayList<>();
	File file = new File("src\\bai4\\word.txt");
	
	public static void main(String[] args){
		bai4 b = new bai4();
		if(b.load()){
			b.start();
		}
	}
	
	//menu
	public void start(){
			Scanner in = new Scanner(System.in);
			System.out.println("Dictionary Menu\n"
					+ "1. Them tu\n"
					+ "2. Tra tu\n"
					+ "3. Chinh sua\n"
					+ "4. Thoat");
			int so = in.nextInt();
			switch(so){
				case 1:
					addWord();
					break;
				case 2:
					find();
					break;
				case 3:
					editWord();
					break;
				case 4:
					exit();
					break;
				default:
					System.out.println("Ban da chon sai. Moi ban chon lai");
					start();
			}
			System.out.println("chuong trinh ket thuc");
	}
	
	//nap du lieu cho tu dien
	public boolean load(){
		boolean t = false;	
		if(file.exists()){
			t = true;
			Scanner inf = null;
			try {
				inf = new Scanner(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			while(inf.hasNextLine()){
				String[] s = inf.nextLine().split(":");
				String[] str = s[1].split("-");
				Word w = new Word(s[0],str);
				dictionary.add(w);
			}
		}else{
			System.out.println("File khong ton tai");
		}
		return t;
	}
	
	//them tu
	public void addWord(){
		Scanner in = new Scanner(System.in);
		System.out.println("Keyword: ");
		String key = in.nextLine();
		System.out.println("Value: ");
		String value = in.nextLine();
		boolean t = false;
		for (Word word : dictionary) {
			if(word.getKey().equals(key)){
				t = true; 
				word.getArray().add(value);
				break;
			}
		}
		if(!t){
			Word w = new Word(key, value);
			dictionary.add(w);
		}
		save();
		start();
	}
	
	//tim tu
	public void find(){
		Scanner in = new Scanner(System.in);
		System.out.println("nhap tu khoa: ");
		String key = in.nextLine();
		boolean t = false;
		for (Word word : dictionary) {
			if(word.getKey().equals(key)){
				t = true;
				System.out.println("nghia: ");
				String s = "";
				for(String str: word.getArray()){
					s += str+ "\n";
				}
				System.out.println(s);
			}
		}
		if(!t){
			System.out.println("khong tim thay nghia");
		}
		System.out.println("nhap ki tu bat ki de ve menu");
		in.nextLine();
		start();
	}
	
	//chinh sua tu
	public void editWord(){
		Scanner in = new Scanner(System.in);
		System.out.println("Keyword: ");
		String key = in.nextLine();
		System.out.println("value: ");
		String value = in.nextLine();
		for (Word word : dictionary) {
			if(word.getKey().equals(key)){
				ArrayList<String> a = new ArrayList<String>();
				a.add(value);
				word.setArray(a);
				break;
			}
		}
		save();
		start();
	}
	
	//thoat
	public void exit(){
		Scanner in = new Scanner(System.in);
		System.out.println("co muon thoat khong?(Y/N)");
		String s = in.nextLine();
		if(s.equals("N")){
			start();
		}
	}
	
	public void save(){	
		String str = "";
		for(Word w:dictionary){
			str += w.getKey()+":";
			for(String s:w.getArray()){
				str += s+"-";
			}
			str += "\n";
		}
		
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(file));
			bw.write(str);
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}


