package bai4;

import java.util.ArrayList;

public class Word {
	private String key;
	private ArrayList<String> array = new ArrayList<>();
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public ArrayList<String> getArray() {
		return array;
	}
	public void setArray(ArrayList<String> array) {
		this.array = array;
	}
	
	public Word(String key, String value){
		this.key = key;
		this.array.add(value);
	}
	
	public Word(String key, String[] array){
		this.key = key;
		for(String s:array){
			this.array.add(s);
		}
	}
}
