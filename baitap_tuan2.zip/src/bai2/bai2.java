package bai2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class bai2 {
	
	public boolean t = true;
	static int sai = 0;
	
	public static void main(String[] args){
		dangNhap();
	} 
	
	//kiem tra tai khoan
	public static boolean kiemTra(String name, String pass){
		File file = new File("src\\bai2\\txt.txt");
		if(file.exists()){
	        FileReader fr = null;
			try {
				fr = new FileReader(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	        BufferedReader br = new BufferedReader(fr);
	        String[] s = null;
	        try {
				s = br.readLine().split(" ");
			} catch (IOException e) {
				e.printStackTrace();
			}
	        if(s[0].equals(name) && s[1].equals(pass)){
	        	try {
					fr.close();
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        	
	        	return true;
	        }
		}else{
			System.out.println("File khong ton tai");
		}	
		return false;
	}
	
	//dang nhap
	public static void dangNhap(){	
		Scanner in = new Scanner(System.in);
		System.out.println("Dang nhap");	
		System.out.println("Tai khoan");
		String name =  in.nextLine();
		System.out.println("Mat khau");
		String pass = in.nextLine();
		
		if(kiemTra(name, pass)){
			sai = 0;
			menu1();
		}else{
			sai++;
			if(sai == 3){
				try {
					System.out.println("Ban nhap sai qua 3 lan, xin doi 60 giay");
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				sai = 0;
				dangNhap();
			}else{
				System.out.println("Dang nhap sai, co muon dang nhap lai khong Y/N");
				String nhaplai = in.nextLine();
				if(nhaplai == "Y"){
					dangNhap();
				}
			}
		}
		System.out.println("chuong trinh ket thuc");
	}
	
	//menu1
	public static void menu1(){
		System.out.println("1. Nhap kho\n"
				+ "2. Xuat kho\n"
				+ "3.Quan lu gia\n"
				+ "4.In hoa don\n"
				+ "5.Thoat");
		Scanner in = new Scanner(System.in);
		int so = in.nextInt();
		switch(so){
			case 1:
				nhapKhoMenu();
				break;
			case 2:
				xuatKhoMenu();
				break;
			case 3:
				quanLiGia();
				break;
			case 4:
				inHoaDon();
				break;
			case 5:
				thoat();
				break;
		}
	}
	
	//nhap kho menu
	public static void nhapKhoMenu(){
		System.out.println("1. Nhap kho so luong mot don vi\n"
				+ "2. Nhap theo thung 20 don vi\n"
				+ "3. Nhap theo ta 10 don vi\n"
				+ "4. Chinh sua so luong\n"
				+ "5. Quay lai menu 1");
		Scanner in = new Scanner(System.in);
		int so = in.nextInt();
		switch(so){
		case 5: 
			menu1();
			break;
		}
	}
	
	//xuat kho menu
	public static void xuatKhoMenu(){
		System.out.println("1. Xuat theo mot don vi\n"
				+ "2. Xuat theo thung\n"
				+ "3. Xuat theo ta\n"
				+ "4. Chinh so luong\n"
				+ "5. Kiem tra so luong\n"
				+ "6. Quay lai menu1");
		Scanner in = new Scanner(System.in);
		int so = in.nextInt();
		switch(so){
		case 6: 
			menu1();
			break;
		}
	}
	
	//quan li gia
	public static void quanLiGia(){
		System.out.println("1. Hien thi gia\n"
				+ "2. Sua gia\n"
				+ "3. Tong tien hang\n"
				+ "4. Quay lai menu1");
		Scanner in = new Scanner(System.in);
		int so = in.nextInt();
		switch(so){
		case 4: 
			menu1();
			break;
		}
	}
	
	//in hoa don
	public static void inHoaDon(){
		System.out.println("1. In theo luong hang\n"
				+ "2. In theo gia\n"
				+ "3. In theo ca hang va gia\n"
				+ "4. Quay lai menu1");
		Scanner in = new Scanner(System.in);
		int so = in.nextInt();
		switch(so){
		case 4: 
			menu1();
			break;
		}
	}
	
	//thoat
	public static void thoat(){
		System.out.println("Ban co muon thoat khong?(Y/N)");
		Scanner in = new Scanner(System.in);
		String s = in.nextLine();
		if(s.equals("N")){
			menu1();
		}
	}
}
