package bai3;

import java.util.Scanner;

public class bai3{
	
	public static void main(String[] args){
		Scanner in =new Scanner(System.in);
		System.out.println("Nhap vao chuoi:");
		String s = in.nextLine();
		System.out.println("Chon chuc nang\n"
				+ "1. In chuoi nghich dao\n"
				+ "2. In chuoi co ki tu dau hang viet hoa\n"
				+ "3. In chuoi co cac ki tu dau viet hoa\n"
				+ "4. In ra chuoi viet hoa\n"
				+ "5. Ma hoa chuoi");
		int so = in.nextInt();
		switch(so){
			case 1:
				System.out.println("chuoi nghich dao cua chuoi vua nhap:");
				System.out.println(reverseString(s));
				break;
			case 2:
				System.out.println("chuoi co ki tu dau hang viet hoa:");
				System.out.println(upperFirstChart(s));
				break;
			case 3:
				System.out.println("chuoi co ki dau viet hoa:");
				System.out.println(upperChartString(s));
				break;
			case 4:
				System.out.println("chuoi viet hoa:");
				System.out.println(upperString(s));
				break;
			case 5:
				System.out.println("ma hoa chuoi:");
				System.out.println(changeString(s));
				break;
		}
	}
	
	//dao chuoi
	public static String reverseString(String s){
		StringBuffer sb = new StringBuffer(s);
		return sb.toString();
	} 
	
	//viet hoa ki tu dau
	public static String upperFirstChart(String s){
		String s1 = "";
		for(int i = 0;  i < s.length(); i++){
			if(s.charAt(i) == ' '){
				continue;
			}else{
				String s2 = (String.valueOf(s.charAt(i))).toUpperCase();
				StringBuffer sb = new StringBuffer(s);
				s1 = sb.replace(i, i+1, s2).toString();
				break;
			}
		}
		return s1;
	}
	
	//viet hoa cac ky tu dau
	public static String upperChartString(String s){
		String s1 = upperFirstChart(s);	
		StringBuffer sb = new StringBuffer(s1);
		for(int i = 0; i< s1.length(); i++){
			if(s.charAt(i) == ' ' && s.charAt(i+1) !=' '){
				String s2 = (String.valueOf(s.charAt(i+1))).toUpperCase();	
				sb.replace(i+1, i+2, s2);
			}
		}
		return sb.toString();
	}
	
	//upper string
	public static String upperString(String s){
		return s.toUpperCase();
	}
	
	//ma hoa chuoi
	public static String changeString(String s){
		StringBuffer sb = new StringBuffer(s);
		for(int i= 0 ; i < s.length(); i++){
			if(s.charAt(i) != ' '){
				char c = (char)(s.charAt(i) + 1);
				sb.replace(i, i+1, String.valueOf(c));
			}
		}
		return sb.toString();
	}
}
