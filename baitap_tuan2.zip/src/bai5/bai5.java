package bai5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class bai5 {
	ArrayList<_Char> list = new ArrayList<>();
	
	//doc file
	public String readFile(){
		File file = new File("src\\bai5\\string.txt");
		String s = "";
		if(file.exists()){
			FileReader fr = null;
			try {
				fr = new FileReader(file);
				Scanner in = new Scanner(fr);
				while(in.hasNextLine()){
					s += in.nextLine();
				}
				fr.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch(IOException e){
				e.printStackTrace();
			}	
		}else{
			System.out.println("File khong ton tai");
		}
		return s;
	}
	
	//dem tu
	public void countChar(String s){	
		for(int i = 0; i< s.length(); i++){
			if(s.charAt(i) != ' '){
				boolean t = false;
				for (_Char c : list) {
					if(c.getC() == s.charAt(i)){
						c.addCount();
						t = true;
						break;
					}
				}
				if(!t){
					_Char c = new _Char(s.charAt(i));
					list.add(c);
				}
			}
		}
	}
	
	//hien thi
	public void disPlay(){
		String str = "";
		for(_Char c: list){
			str += c.getC()+" "+c.getCount() +"\n";
		}
		System.out.println(str);
	}
	
	public static void main(String[] args){
		bai5 b = new bai5();
		b.countChar(b.readFile());
		b.disPlay();
	}
}
