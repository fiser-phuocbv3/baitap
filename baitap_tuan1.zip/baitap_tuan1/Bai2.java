import java.util.Arrays;
import java.util.Scanner;


class Bai2 {
	static int countSum = 0;
	static int countMinus = 0;
	static int countMulti = 0;
	static int countDevide = 0;
	private int m = 0;
	private int sumArray = 0;
	private int minusArray = 0;
	private int multiArray = 1;
	private int devideArray = 0;
	private int temp[], sortArr[];
	
	public Bai2(int m, int k1)	{
		this.m = m;
		temp = new int[k1];
	}
	
	public void swapArray(int array[],int k, int k1, int i1)	{
		if (k1 == k) { 
					sortArr = new int[temp.length];
					sortArr = Arrays.copyOf(temp, temp.length);
				    Arrays.sort(sortArr);
		   			if (sumArr(temp) == m) 	 countSum++;
		   			if (multiArr(temp) == m)  countMulti++;
		   			if (minusArr(sortArr) == m)  countMinus++;
		   			if (devideArr(sortArr) == m) countDevide++;
		}else	{
				for	(int i = i1; i < array.length; i++)	{
					temp[k1] = array[i];
					swapArray(array, k, k1 + 1, i +1);
				}	
		}
	}
	
	
	public int sumArr(int array[])	{
		sumArray = 0;
		for	(int i = 0; i < array.length; i++ )	{
			sumArray += array[i];	
		}
		return sumArray;
	}
	
	public int minusArr(int array[])	{
		minusArray = array[array.length - 1];
		for	(int i = 0; i < array.length - 1; i++ )	{
			minusArray -= 	array[i];
		}
		return minusArray;
	}
	
	public int multiArr(int array[])	{
	multiArray = 1;
		for	(int i = 0; i < array.length; i++ )	{
			multiArray *= array[i];
		}
		return multiArray;
	}
	public int devideArr(int array[])	{
		devideArray = array[array.length - 1];
		for	(int i = array.length - 2; i >= 0; i-- )	{
			if(array[i] == 0) return 0;	
				devideArray /= array[i];
		}
		return devideArray;
	}
	public int getCountSum()	{
		return countSum;
	}
	public int getCountMinus()	{
		return countMinus;
	}
	public int getCountMulti()	{
		return countMulti;
	}
	public int getCountDevide()	{
		return countDevide;
	}
	
	public static void main(String args[])	{
    	int countSum = 0;
	    int countMinus = 0;
	    int countMulti = 0;
		int countDevide = 0;
		int lengthArray = 0;
		int array[];
		int i = 0;
		int m = 0;
		
		Scanner	scanner = new Scanner(System.in);
		lengthArray = scanner.nextInt();
		array = new int[lengthArray];
		
		for	(i = 0; i < lengthArray; i++)	{
			array[i] = scanner.nextInt();
		}
		m = scanner.nextInt();
		
		for(i = 2; i <= array.length; i++)	{
			Bai2 bai2 = new Bai2(m,i);
			bai2.swapArray(array, i, 0, 0);
			countSum = bai2.getCountSum();
			countMinus = bai2.getCountMinus();
			countMulti = bai2.getCountMulti();
			countDevide =bai2.getCountDevide();
		}
		System.out.println(countSum);
		System.out.println(countMinus);
		System.out.println(countMulti);
		System.out.println(countDevide);
		}
	
}
