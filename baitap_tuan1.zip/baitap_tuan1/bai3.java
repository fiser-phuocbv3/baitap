import java.util.Scanner;

public class bai1 {
	
	public static void main(String[] args){
		
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();
		String[] array_str = str.split(" ");
		
		array_str = xuly(array_str);
		String s = dem(array_str);
		System.out.println(s);
	}
	
	//xu ly cat chuoi
	public static String[] xuly(String[] array){
		
		for(int i = 0; i< array.length; i++){
			if(array[i].endsWith(".") || array[i].endsWith(",")){
				array[i] = array[i].substring(0, array[i].length()-1);
			}
			array[i] = array[i].toLowerCase();
		}
		return array;
	} 
	
	//dem cac gia tri
	public static String dem(String[] array){
		String s = "";
		int c = 0;
		for(int i=0; i<array.length;i++){
			if(array[i] !=""){
				String str = array[i];
				int count = 0; 
				for(int j=0; j< array.length;j++){
					if(str.equals(array[j])){
						count++;
						array[j] = "";
					}
				}
				s += str +" "+count+"-"; 
				
				c++;
			}
			
		}
		s = xapxep(c, s);
		return s;
	}
	
	//xap xep theo thu tu
	public static String xapxep(int c, String str){
		String str1 = "";
		String[] s = str.split("-");
		String[] ak = new String[c];
		int[] av = new int[c];
		for(int i= 0; i<s.length;i++){
			ak[i] = s[i].split(" ")[0];
			av[i] = Integer.parseInt(s[i].split(" ")[1]);
		}
		
		for(int i = 0; i < c-1; i++ ){
			for(int j=i+1; j<c;j++){
				if(av[j] > av[i]){
					int temp;
					temp = av[j];
					av[j] = av[i];
					av[i] = temp;
					
					String temps;
					temps = ak[j];
					ak[j] = ak[i];
					ak[i] = temps;
				}
			}
			
		}
		
		for(int i = 0; i < c-1; i++ ){
			int value = av[i] ;
			for(int j=i+1; j<c;j++){
				if(av[j] == value){
					if(ak[j].charAt(0) < ak[i].charAt(0)){
						String temps;
						temps = ak[j];
						ak[j] = ak[i];
						ak[i] = temps;
						
						int temp;
						temp = av[j];
						av[j] = av[i];
						av[i] = temp;
					}
				}
			}
		}
		
		for(int i = 0; i < c; i++ ){
			str1 += ak[i] +" "+av[i]+"\n";
		}
		return str1;
	}

}