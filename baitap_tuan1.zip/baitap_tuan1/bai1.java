public class bai1 {

	public static void main(String[] args){
		int n  = Integer.parseInt(args[0]);
		int[] array = new int[n];
		
		for(int i = 1; i <= n; i++){
			array[i-1] = Integer.parseInt(args[i]);
		}
		min_max(array);
		giam(array);
		hienthi(array);
		tang(array);
		hienthi(array);
	}
	
	public static void min_max(int[] array){
		int max = array[0];
		int min = array[0];
		for(int i=1; i < array.length; i++){
			if(array[i] > max){
				max = array[i];
			}if(array[i]< min){
				min = array[i];
			}
		}
		System.out.println(max+" "+min);
	}
	
	public static int[] giam(int[] array){
		int temp;
		for(int i=0; i < array.length-1 ; i++){
			for(int j=i+1; j < array.length; j++){
				if(array[j]>array[i]){
					temp = array[j];
					array[j] = array[i];
					array[i] = temp;
				}
			}
		}
		return array;
	}
	
	public static int[] tang(int[] array){
		int temp;
		for(int i=0; i < array.length-1 ; i++){
			for(int j=i+1; j < array.length; j++){
				if(array[j]<array[i]){
					temp = array[j];
					array[j] = array[i];
					array[i] = temp;
				}
			}
		}
		return array;
	}
	
	public static void hienthi(int[] array){
		for(int i=0; i< array.length; i++){
			System.out.print(array[i]+ " ");
		}
		System.out.println("");
	}
}
