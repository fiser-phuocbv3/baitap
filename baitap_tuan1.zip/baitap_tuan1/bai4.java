package bai1;


import java.util.Scanner;

class MatrixChar {

	private char array[][];
	private int n, m;
	private String str;
	char arrStr[];

	public MatrixChar(char array[][], String str, int n, int m) {
		this.n = n;
		this.m = m;
		this.str = str;
		this.array = array;
	}

	//chieu doc
	public int getDoc() {
		int countVerti = 0;
		arrStr = new char[this.n];
		for (int j = 0; j < this.m; j++) {
			for (int i = 0; i < this.n; i++) {
				arrStr[i] = this.array[i][j];
			}
			countVerti += getCountSubStr(this.str, arrStr);
		}
		return countVerti;
	}

	//chieu ngang
	public int getNgang() {
		int countHorizon = 0;
		arrStr = new char[this.m];
		for (int i = 0; i < this.n; i++) {
			for (int j = 0; j < this.m; j++) {
				arrStr[j] = this.array[i][j];
			}
			countHorizon += getCountSubStr(this.str, arrStr);
		}
		return countHorizon;
	}

	public int getCheo() {
		int countDiagon = 0;
		int maxSize = n > m ? n : m;
		int j = 0;
		int j1 = 0;
		int i = 0;
		int i1 = 0;
		while (j < m) {
			arrStr = new char[maxSize];
			j1 = j;
			i = 0;
			while ((j1 >= 0) && (i < n)) {
				arrStr[i] = array[i][j1];
				j1--;
				i++;
			}
			countDiagon += getCountSubStr(str, arrStr);
			j++;
		}
	
		i = 1 ;
		while (i < n) {
			arrStr = new char[maxSize];
			i1 = i;
			j = m - 1;
			while ((i1 < n) && (j >= 0)) {
				arrStr[m -1 - j] = array[i1][j];
				i1++;
				j--;
			}
			countDiagon += getCountSubStr(str, arrStr);
			i++;
		}
		
		i = 0;
		while (i < this.n) {
			arrStr = new char[maxSize];
			i1 = i;
			j = 0;
			while ((i1 < this.n) && (j < this.m)) {
				arrStr[j] = this.array[i1][j];
				i1++;
				j++;
			}
			countDiagon += getCountSubStr(str, arrStr);
			i++;
		}

		j = 1;
		while (j < this.m) {
			arrStr = new char[maxSize];
			i = 0;
			j1 = j;
			while ((i < this.n) && (j1 < this.m)) {
				arrStr[i] = this.array[i][j1];
				i++;
				j1++;
			}
			countDiagon += getCountSubStr(str, arrStr);
			j++;
		}
		return countDiagon;
	}

	public int getCountSubStr(String str, char arrStr1[]) {

		int count = 0;
		char arrStr[] = str.toCharArray();
		if (arrStr.length > arrStr1.length)
			return 0;
		int i = 0;
		int j = 0;

		while ((i < arrStr.length) && (j < arrStr1.length)) {
			if (arrStr[i] == arrStr1[j]) {
				i++;
			}
			j++;
		}
		if (i == arrStr.length) {
			count++;
		}

		i = 0;
		j = arrStr1.length - 1;
		while ((i < arrStr.length) && (j >= 0)) {
			if (arrStr[i] == arrStr1[j]) {
				i++;
			}
			j--;
		}
		if (i == arrStr.length) {
			count++;
		}

		return count;
	}

	public static void main(String args[]) {
		int n, m;
		String str = null;
		char array[][];

		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		m = in.nextInt();
		array = new char[n][m];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				array[i][j] = in.next().charAt(0);

			}
			in.nextLine();
		}

		str = in.nextLine();

		MatrixChar matrix = new MatrixChar(array, str, n, m);
		System.out.println("Doc: "+matrix.getDoc());
		System.out.println("Ngang: "+matrix.getNgang());
		System.out.println("Cheo: "+matrix.getCheo());

	}
}

