package connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Test {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		int c = SqlConfig.insert("Nguyen Van B", 20, "Ha Noi");
		String sql = "select * from table1";
		ResultSet rs = null;
		try {
			rs = SqlConfig.returnResult(sql);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		while(rs.next()){
			int id = rs.getInt("ID");
			String name = rs.getString("Name");
			int age = rs.getInt("Age");
			String address = rs.getString("Address");
			System.out.println("id: "+id+", name: "+name+", age: "+age+", address:"+address);
		}
		
		SqlConfig.closeConnect();
	}

}
