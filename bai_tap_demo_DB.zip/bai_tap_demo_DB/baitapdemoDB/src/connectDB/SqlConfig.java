package connectDB;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class SqlConfig {
	
	private static Connection connect = null;
	
	public static Connection getConnect() throws ClassNotFoundException{
		String hostName = "localhost";
		String dbName = "data";
		String userName = "root";
		String passWord = "";
		if(connect == null){
			Connection conn = ConnectDB(hostName, dbName, userName, passWord);
			return conn;
		}
		return connect;
	}
	
	public static Connection ConnectDB(String hostName, String dbName, 
			String userName, String passWord) throws ClassNotFoundException{
		
		Class.forName("com.mysql.jdbc.Driver");
		String connectURL = "jdbc:mysql://" + hostName + ":3306/" + dbName;
		Connection conn = null;
		try {
			conn = (Connection) DriverManager.getConnection(connectURL, userName, passWord);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;		
	}
	
	public static ResultSet returnResult(String sql) throws ClassNotFoundException, SQLException{
		connect = getConnect();
		Statement statement = (Statement) connect.createStatement();
		ResultSet rs = statement.executeQuery(sql);
		return rs;
	}
	
	public static int insert(String name, int age, String address) throws ClassNotFoundException, SQLException{
		//String sql = "Insert into table1 (Name, Age, Address) values ("+name+","+age+","+address+")";
		String sql = "Insert into table1 (Name, Age, Address) values ('"+name+"',"+age+",'"+address+"')";
		connect = getConnect();
		Statement statement = (Statement) connect.createStatement();
		int rs = statement.executeUpdate(sql);
		return rs;
	}
	
	public static void closeConnect() throws SQLException{
		connect.close();
	}
}
